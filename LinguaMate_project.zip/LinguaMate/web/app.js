const $ = id => document.getElementById(id);
let token = localStorage.getItem("lm_token") || "";
let username = localStorage.getItem("lm_user") || "";
let authMode = "login";
let words = [];
let currentWord = null;
let quiz = [];
let quizIndex = 0;
let quizScore = 0;
let answered = false;

async function api(path, options={}) {
  const headers = {"Content-Type":"application/json", ...(options.headers||{})};
  if (token) headers.Authorization = "Bearer " + token;
  const response = await fetch("/api"+path, {...options, headers});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Ошибка запроса");
  return data;
}
function showAuth() {
  $("auth").classList.remove("hidden"); $("appContent").classList.add("hidden");
  $("logout").style.display="none";
}
function showApp() {
  $("auth").classList.add("hidden"); $("appContent").classList.remove("hidden");
  $("logout").style.display="block"; $("sideUser").textContent=username || "Ученик";
  $("profileBtn").textContent=username || "Ученик";
  refreshAll();
}
function setAuthMode(mode) {
  authMode=mode;
  $("loginTab").classList.toggle("selected",mode==="login");
  $("registerTab").classList.toggle("selected",mode==="register");
  $("authSubmit").textContent=mode==="login"?"Войти":"Создать аккаунт";
  $("authMessage").textContent="";
}
$("loginTab").onclick=()=>setAuthMode("login");
$("registerTab").onclick=()=>setAuthMode("register");
$("authForm").onsubmit=async e=>{
  e.preventDefault(); $("authMessage").textContent="Проверяем данные...";
  try {
    const data=await api(authMode==="login"?"/login":"/register",{method:"POST",body:JSON.stringify({username:$("username").value.trim(),password:$("password").value})});
    token=data.token; username=data.username;
    localStorage.setItem("lm_token",token); localStorage.setItem("lm_user",username);
    showApp();
  } catch(err) {$("authMessage").textContent=err.message;}
};
$("logout").onclick=()=>{token="";username="";localStorage.removeItem("lm_token");localStorage.removeItem("lm_user");showAuth();};

function navigate(page) {
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  $("page-"+page).classList.remove("hidden");
  document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
  const names={home:"Главная",words:"Мой словарь",learn:"Изучение слов",quiz:"Тестирование",dialogues:"Диалоги",review:"Повторение",stats:"Статистика"};
  $("pageTitle").textContent=names[page]||"LinguaMate";
  if(page==="learn") loadNextWord();
  if(page==="quiz") startQuiz();
  if(page==="dialogues" && !$("chatMessages").children.length) loadScenario("cafe");
}
document.querySelectorAll(".nav").forEach(n=>n.onclick=()=>navigate(n.dataset.page));
document.querySelectorAll("[data-go]").forEach(n=>n.onclick=()=>navigate(n.dataset.go));

async function refreshAll() {
  try { words=await api("/words"); renderWords(); await refreshStats(); }
  catch(e){ if(e.message.includes("авторизац")) showAuth(); else console.error(e); }
}
async function refreshStats() {
  const s=await api("/stats");
  $("statWords").textContent=$("statsWords").textContent=s.words;
  $("statDue").textContent=$("statsDue").textContent=s.due;
  $("statCorrect").textContent=$("statsCorrect").textContent=s.correct;
  $("reviewCount").textContent=s.due;
}
function renderWords() {
  const q=$("wordSearch").value.toLowerCase();
  const level=$("levelFilter").value;
  const filtered=words.filter(w=>(w.english.toLowerCase().includes(q)||w.translation.toLowerCase().includes(q))&&(!level||w.level===level));
  $("wordRows").innerHTML=filtered.map(w=>`<tr><td><b>${escapeHtml(w.english)}</b></td><td>${escapeHtml(w.translation)}</td><td><span class="level-pill">${escapeHtml(w.level)}</span></td><td>${escapeHtml(w.example||"—")}</td><td><button class="delete-btn" data-delete="${w.id}" title="Удалить">×</button></td></tr>`).join("");
  $("wordEmpty").classList.toggle("hidden",filtered.length>0);
  document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>deleteWord(Number(b.dataset.delete)));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("wordSearch").oninput=renderWords; $("levelFilter").onchange=renderWords;
$("addWordOpen").onclick=()=>$("wordModal").classList.remove("hidden");
$("modalClose").onclick=()=>$("wordModal").classList.add("hidden");
$("wordModal").onclick=e=>{if(e.target===$("wordModal"))$("wordModal").classList.add("hidden");};
$("wordForm").onsubmit=async e=>{
  e.preventDefault();
  try {
    await api("/words",{method:"POST",body:JSON.stringify({english:$("newEnglish").value.trim(),translation:$("newTranslation").value.trim(),example:$("newExample").value.trim(),level:$("newLevel").value})});
    $("wordForm").reset(); $("wordModal").classList.add("hidden"); await refreshAll();
  } catch(err){$("wordModalMessage").textContent=err.message;}
};
async function deleteWord(id){if(!confirm("Удалить слово из личного словаря?"))return;try{await api("/words/"+id,{method:"DELETE"});await refreshAll();}catch(e){alert(e.message);}}

async function loadNextWord() {
  $("learnMessage").textContent="";
  $("learnTranslation").classList.add("hidden"); $("showTranslation").classList.remove("hidden");
  try {
    currentWord=await api("/learn/next");
    $("learnWord").textContent=currentWord.english; $("learnLevel").textContent=currentWord.level;
    $("learnExample").textContent=currentWord.example;
    $("learnTranslation").textContent=currentWord.translation;
  } catch(e) {currentWord=null;$("learnWord").textContent="Добавь слова в словарь";$("learnExample").textContent=e.message;}
}
$("showTranslation").onclick=()=>{$("learnTranslation").classList.remove("hidden");$("showTranslation").classList.add("hidden");};
$("nextWord").onclick=loadNextWord;
async function answerWord(correct) {
  if(!currentWord)return;
  try {
    const r=await api("/learn/answer",{method:"POST",body:JSON.stringify({wordId:currentWord.id,correct})});
    $("learnMessage").textContent=r.message; await refreshStats(); setTimeout(loadNextWord,850);
  } catch(e){$("learnMessage").textContent=e.message;}
}
$("rightBtn").onclick=()=>answerWord(true); $("wrongBtn").onclick=()=>answerWord(false);

function startQuiz() {
  if(words.length<4){$("quizWord").textContent="Добавь минимум 4 слова";$("quizOptions").innerHTML="";$("quizCounter").textContent="Тест пока недоступен";return;}
  quiz=[...words].sort(()=>Math.random()-.5).slice(0,Math.min(5,words.length));
  quizIndex=0;quizScore=0;renderQuiz();
}
function renderQuiz() {
  answered=false;
  const w=quiz[quizIndex];
  $("quizCounter").textContent=`Вопрос ${quizIndex+1} из ${quiz.length}`;
  $("quizScore").textContent=`${quizScore} верно`;
  $("quizBar").style.width=`${quizIndex/quiz.length*100}%`;
  $("quizWord").textContent=w.english; $("quizFeedback").textContent="";
  $("quizNext").classList.add("hidden");
  const wrong=words.filter(x=>x.id!==w.id).sort(()=>Math.random()-.5).slice(0,3);
  const options=[w,...wrong].sort(()=>Math.random()-.5);
  $("quizOptions").innerHTML=options.map(x=>`<button class="option" data-id="${x.id}">${escapeHtml(x.translation)}</button>`).join("");
  document.querySelectorAll(".option").forEach(b=>b.onclick=()=>chooseQuiz(Number(b.dataset.id),w.id,b));
}
function chooseQuiz(selected,correctId,button) {
  if(answered)return;answered=true;
  document.querySelectorAll(".option").forEach(b=>{b.disabled=true;if(Number(b.dataset.id)===correctId)b.classList.add("correct");});
  if(selected===correctId){quizScore++;$("quizFeedback").textContent="Верно! Отличная работа.";}
  else {button.classList.add("wrong");$("quizFeedback").textContent="Пока не совсем. Правильный ответ отмечен зелёным.";}
  api("/learn/answer",{method:"POST",body:JSON.stringify({wordId:correctId,correct:selected===correctId})})
    .then(refreshStats).catch(err=>console.error(err));
  $("quizScore").textContent=`${quizScore} верно`;
  $("quizNext").classList.remove("hidden");
}
$("quizNext").onclick=()=>{
  quizIndex++;
  if(quizIndex>=quiz.length){
    $("quizWord").textContent=`${quizScore} из ${quiz.length}`;
    $("quizOptions").innerHTML="";$("quizFeedback").textContent="Тест завершён. Продолжай практиковаться!";
    $("quizNext").textContent="Пройти ещё раз";$("quizNext").onclick=()=>{$("quizNext").textContent="Следующий вопрос →";startQuiz();};
    $("quizBar").style.width="100%";
  } else renderQuiz();
};

const scenarios={
 cafe:{title:"В кафе",start:"Hello! Welcome to our café. What would you like?",choices:[["I'd like a coffee, please.","Of course. Would you like anything to eat?"],["Can I see the menu?","Sure! Here is the menu. What would you like to drink?"],["Could I have some tea?","Certainly. Would you like milk or lemon?"]],end:"Thank you! Your order will be ready soon."},
 airport:{title:"В аэропорту",start:"Good morning! May I see your passport, please?",choices:[["Here you are.","Thank you. Are you checking in any luggage?"],["Where is gate number 12?","Gate 12 is on your right, after security."],["What time does boarding start?","Boarding starts at 10:30. Please be at the gate on time."]],end:"Have a nice flight!"},
 meeting:{title:"Знакомство",start:"Hi! I'm Alex. Nice to meet you. What's your name?",choices:[["I'm Sam. Nice to meet you too!","Nice to meet you, Sam. Where are you from?"],["I'm from Russia.","That's interesting! What do you do?"],["I study at university.","Great! What are you studying?"]],end:"It was nice talking to you. See you soon!"}
};
function loadScenario(key) {
  document.querySelectorAll(".scenario").forEach(b=>b.classList.toggle("active",b.dataset.scenario===key));
  const s=scenarios[key];$("dialogueTitle").textContent=s.title;
  $("chatMessages").innerHTML=`<div class="bubble">${escapeHtml(s.start)}<small>Собеседник</small></div>`;
  $("chatChoices").innerHTML=s.choices.map((c,i)=>`<button data-choice="${i}">${escapeHtml(c[0])}</button>`).join("");
  document.querySelectorAll("[data-choice]").forEach(b=>b.onclick=()=> {
    const c=s.choices[Number(b.dataset.choice)];
    $("chatMessages").innerHTML+=`<div class="bubble user">${escapeHtml(c[0])}<small>Ты</small></div><div class="bubble">${escapeHtml(c[1])}<small>Собеседник</small></div>`;
    $("chatMessages").scrollTop=$("chatMessages").scrollHeight;
    $("chatChoices").innerHTML=`<button id="dialogueContinue">Продолжить диалог</button>`;
    $("dialogueContinue").onclick=()=>{$("chatMessages").innerHTML+=`<div class="bubble">${escapeHtml(s.end)}<small>Собеседник</small></div>`;$("chatChoices").innerHTML=`<button id="dialogueRestart">Повторить сценарий</button>`;$("dialogueRestart").onclick=()=>loadScenario(key);};
  });
}
document.querySelectorAll(".scenario").forEach(b=>b.onclick=()=>loadScenario(b.dataset.scenario));

(async function init(){
  document.querySelectorAll("[data-go]").forEach(n=>n.onclick=()=>navigate(n.dataset.go));
  if(token){try{await api("/me");showApp();}catch(e){token="";localStorage.removeItem("lm_token");showAuth();}}
  else showAuth();
})();
