# LinguaMate — персональный помощник для изучения английского

Полноценный учебный MVP веб-приложения: C++17 сервер, SQLite, REST API и адаптивный интерфейс.

## Возможности
- регистрация и вход;
- личный словарь: просмотр, поиск, фильтр по уровню, добавление и удаление слов;
- карточки для изучения;
- сохранение ответов и приоритет сложных слов;
- тест с вариантами ответов;
- три сценарных диалога: кафе, аэропорт, знакомство;
- статистика пользователя;
- SQLite база создаётся автоматически.

## Стек
- C++17
- cpp-httplib — HTTP-сервер
- nlohmann/json — JSON
- SQLite — хранение данных
- OpenSSL — SHA-256 для хеширования паролей
- HTML/CSS/JavaScript — интерфейс

## Требования
- CMake 3.20+
- компилятор C++17 (Visual Studio 2022, GCC или Clang)
- SQLite3 development package
- OpenSSL development package
- доступ к интернету при первой сборке: CMake скачает cpp-httplib и nlohmann/json

## Сборка в Windows (Visual Studio 2022)
Установи workload **Desktop development with C++**, CMake, SQLite3 и OpenSSL.
Открой Developer PowerShell в папке проекта:

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/path/to/vcpkg/installed/x64-windows"
cmake --build build --config Release
cd build
.\Release\linguamate.exe
```

Если используешь vcpkg, установи зависимости:
```powershell
vcpkg install sqlite3 openssl
```
И укажи toolchain-файл при конфигурации:
```powershell
cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE="C:/vcpkg/scripts/buildsystems/vcpkg.cmake"
cmake --build build --config Release
```

## Сборка в Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install build-essential cmake git libsqlite3-dev libssl-dev
cmake -S . -B build
cmake --build build -j
cd build
./linguamate
```

## Запуск
Открой в браузере:

http://localhost:8080

Создай аккаунт (логин от 3 символов, пароль от 6 символов). При первом запуске в базе появятся демонстрационные слова.

## Где хранятся данные
`linguamate.db` создаётся в текущей рабочей папке при запуске сервера. Не удаляй его, если хочешь сохранить пользователей и прогресс.

## Структура
```text
LinguaMate/
├── CMakeLists.txt
├── README.md
├── src/
│   ├── main.cpp
│   ├── database.cpp
│   ├── database.h
│   ├── security.cpp
│   └── security.h
├── web/
│   ├── index.html
│   ├── style.css
│   └── app.js
└── data/
```

## Важные ограничения текущей версии
- Диалоги работают как сценарный тренажёр, а не как свободный ИИ-чат.
- Тесты формируются из личного словаря.
- Повторение использует простую учебную эвристику: ошибки получают приоритет, правильный ответ переносит повторение на следующий день.
- SHA-256 без индивидуальной соли — упрощение учебного прототипа. Для публичного запуска нужно заменить на Argon2id/bcrypt, добавить ограничение попыток входа, HTTPS, CSRF-защиту, управление сессиями и проверку входных данных.
- Текущая авторизация хранит токены в памяти сервера: после перезапуска потребуется войти заново.
