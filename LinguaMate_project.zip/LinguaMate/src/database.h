#pragma once
#include <sqlite3.h>
#include <string>
#include <vector>
#include <optional>

struct Word {
    int id{};
    std::string english;
    std::string translation;
    std::string example;
    std::string level;
};

class Database {
public:
    explicit Database(const std::string& path);
    ~Database();
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    bool registerUser(const std::string& username, const std::string& passwordHash);
    std::optional<int> authenticate(const std::string& username, const std::string& passwordHash);
    std::vector<Word> getWords(int userId);
    bool addWord(int userId, const std::string& english, const std::string& translation,
                 const std::string& example, const std::string& level);
    bool deleteWord(int userId, int wordId);
    std::optional<Word> nextWord(int userId);
    bool recordAnswer(int userId, int wordId, bool correct);
    int totalLearned(int userId);
    int dueCount(int userId);
    int correctAnswers(int userId);
    void seedWords();
private:
    sqlite3* db_{nullptr};
    void execute(const std::string& sql);
    void initialize();
};
