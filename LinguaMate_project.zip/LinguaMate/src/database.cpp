#include "database.h"
#include <stdexcept>

Database::Database(const std::string& path) {
    if (sqlite3_open(path.c_str(), &db_) != SQLITE_OK)
        throw std::runtime_error("Не удалось открыть базу данных SQLite");
    execute("PRAGMA foreign_keys = ON;");
    initialize();
}

Database::~Database() {
    if (db_) sqlite3_close(db_);
}

void Database::execute(const std::string& sql) {
    char* error = nullptr;
    if (sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
        std::string message = error ? error : "SQLite error";
        sqlite3_free(error);
        throw std::runtime_error(message);
    }
}

void Database::initialize() {
    execute(R"SQL(
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS words(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            english TEXT NOT NULL,
            translation TEXT NOT NULL,
            example TEXT NOT NULL DEFAULT '',
            level TEXT NOT NULL DEFAULT 'A1'
        );
        CREATE TABLE IF NOT EXISTS user_words(
            user_id INTEGER NOT NULL,
            word_id INTEGER NOT NULL,
            correct_count INTEGER NOT NULL DEFAULT 0,
            wrong_count INTEGER NOT NULL DEFAULT 0,
            due_at TEXT DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(user_id, word_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(word_id) REFERENCES words(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS answer_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            word_id INTEGER NOT NULL,
            is_correct INTEGER NOT NULL,
            answered_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(word_id) REFERENCES words(id) ON DELETE CASCADE
        );
    )SQL");
    seedWords();
}

void Database::seedWords() {
    sqlite3_stmt* check = nullptr;
    sqlite3_prepare_v2(db_, "SELECT COUNT(*) FROM words", -1, &check, nullptr);
    int count = 0;
    if (sqlite3_step(check) == SQLITE_ROW) count = sqlite3_column_int(check, 0);
    sqlite3_finalize(check);
    if (count > 0) return;

    struct Seed { const char* en; const char* ru; const char* ex; const char* level; };
    const Seed words[] = {
        {"apple","яблоко","I eat an apple every morning.","A1"},
        {"journey","путешествие","Our journey was exciting.","A2"},
        {"improve","улучшать","I want to improve my English.","A2"},
        {"careful","осторожный","Be careful when you cross the road.","A1"},
        {"opportunity","возможность","This is a great opportunity.","B1"},
        {"although","хотя","Although it was cold, we went out.","B1"},
        {"environment","окружающая среда","We should protect the environment.","B1"},
        {"reliable","надёжный","She is a reliable friend.","B2"},
        {"achieve","достигать","You can achieve your goals.","B1"},
        {"conversation","разговор","We had a long conversation.","A2"},
        {"borrow","брать взаймы","Can I borrow your pen?","A2"},
        {"quiet","тихий","This is a quiet place.","A1"}
    };
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db_, "INSERT INTO words(english,translation,example,level) VALUES(?,?,?,?)", -1, &stmt, nullptr);
    for (const auto& w : words) {
        sqlite3_bind_text(stmt,1,w.en,-1,SQLITE_STATIC);
        sqlite3_bind_text(stmt,2,w.ru,-1,SQLITE_STATIC);
        sqlite3_bind_text(stmt,3,w.ex,-1,SQLITE_STATIC);
        sqlite3_bind_text(stmt,4,w.level,-1,SQLITE_STATIC);
        sqlite3_step(stmt);
        sqlite3_reset(stmt);
        sqlite3_clear_bindings(stmt);
    }
    sqlite3_finalize(stmt);
}

bool Database::registerUser(const std::string& username, const std::string& hash) {
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db_, "INSERT INTO users(username,password_hash) VALUES(?,?)", -1, &stmt, nullptr);
    sqlite3_bind_text(stmt,1,username.c_str(),-1,SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt,2,hash.c_str(),-1,SQLITE_TRANSIENT);
    bool ok = sqlite3_step(stmt) == SQLITE_DONE;
    sqlite3_finalize(stmt);
    if (!ok) return false;

    const int userId = static_cast<int>(sqlite3_last_insert_rowid(db_));
    sqlite3_stmt* link = nullptr;
    sqlite3_prepare_v2(db_, "INSERT OR IGNORE INTO user_words(user_id,word_id) SELECT ?,id FROM words", -1, &link, nullptr);
    sqlite3_bind_int(link, 1, userId);
    ok = sqlite3_step(link) == SQLITE_DONE;
    sqlite3_finalize(link);
    return ok;
}

std::optional<int> Database::authenticate(const std::string& username, const std::string& hash) {
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db_, "SELECT id FROM users WHERE username=? AND password_hash=?", -1, &stmt, nullptr);
    sqlite3_bind_text(stmt,1,username.c_str(),-1,SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt,2,hash.c_str(),-1,SQLITE_TRANSIENT);
    std::optional<int> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) result = sqlite3_column_int(stmt,0);
    sqlite3_finalize(stmt);
    return result;
}

std::vector<Word> Database::getWords(int userId) {
    std::vector<Word> result;
    const char* sql = R"SQL(SELECT w.id,w.english,w.translation,w.example,w.level
        FROM words w JOIN user_words uw ON uw.word_id=w.id
        WHERE uw.user_id=? ORDER BY w.id)SQL";
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt,1,userId);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        result.push_back({
            sqlite3_column_int(stmt,0),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,1)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,2)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,3)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,4))
        });
    }
    sqlite3_finalize(stmt);
    return result;
}

bool Database::addWord(int userId, const std::string& en, const std::string& ru,
                       const std::string& ex, const std::string& level) {
    sqlite3_stmt* find = nullptr;
    sqlite3_prepare_v2(db_, "SELECT id FROM words WHERE lower(english)=lower(?)", -1, &find, nullptr);
    sqlite3_bind_text(find,1,en.c_str(),-1,SQLITE_TRANSIENT);
    int wordId = -1;
    if (sqlite3_step(find) == SQLITE_ROW) wordId = sqlite3_column_int(find,0);
    sqlite3_finalize(find);

    if (wordId == -1) {
        sqlite3_stmt* ins = nullptr;
        sqlite3_prepare_v2(db_, "INSERT INTO words(english,translation,example,level) VALUES(?,?,?,?)", -1, &ins, nullptr);
        sqlite3_bind_text(ins,1,en.c_str(),-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(ins,2,ru.c_str(),-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(ins,3,ex.c_str(),-1,SQLITE_TRANSIENT);
        sqlite3_bind_text(ins,4,level.c_str(),-1,SQLITE_TRANSIENT);
        if (sqlite3_step(ins) != SQLITE_DONE) { sqlite3_finalize(ins); return false; }
        sqlite3_finalize(ins);
        wordId = static_cast<int>(sqlite3_last_insert_rowid(db_));
    }

    sqlite3_stmt* link = nullptr;
    sqlite3_prepare_v2(db_, "INSERT OR IGNORE INTO user_words(user_id,word_id) VALUES(?,?)", -1, &link, nullptr);
    sqlite3_bind_int(link,1,userId);
    sqlite3_bind_int(link,2,wordId);
    bool ok = sqlite3_step(link) == SQLITE_DONE;
    sqlite3_finalize(link);
    return ok;
}

bool Database::deleteWord(int userId, int wordId) {
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db_, "DELETE FROM user_words WHERE user_id=? AND word_id=?", -1, &stmt, nullptr);
    sqlite3_bind_int(stmt,1,userId);
    sqlite3_bind_int(stmt,2,wordId);
    bool ok = sqlite3_step(stmt) == SQLITE_DONE && sqlite3_changes(db_) > 0;
    sqlite3_finalize(stmt);
    return ok;
}

std::optional<Word> Database::nextWord(int userId) {
    const char* sql = R"SQL(
      SELECT w.id,w.english,w.translation,w.example,w.level
      FROM words w JOIN user_words uw ON uw.word_id=w.id
      WHERE uw.user_id=? ORDER BY uw.wrong_count DESC, uw.due_at ASC, w.id LIMIT 1
    )SQL";
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db_,sql,-1,&stmt,nullptr);
    sqlite3_bind_int(stmt,1,userId);
    std::optional<Word> result;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        result = Word{
            sqlite3_column_int(stmt,0),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,1)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,2)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,3)),
            reinterpret_cast<const char*>(sqlite3_column_text(stmt,4))
        };
    }
    sqlite3_finalize(stmt);
    return result;
}

bool Database::recordAnswer(int userId, int wordId, bool correct) {
    sqlite3_stmt* history = nullptr;
    sqlite3_prepare_v2(db_, "INSERT INTO answer_history(user_id,word_id,is_correct) VALUES(?,?,?)", -1, &history, nullptr);
    sqlite3_bind_int(history,1,userId);
    sqlite3_bind_int(history,2,wordId);
    sqlite3_bind_int(history,3,correct ? 1 : 0);
    bool ok = sqlite3_step(history) == SQLITE_DONE;
    sqlite3_finalize(history);
    if (!ok) return false;

    const char* sql = correct
        ? "UPDATE user_words SET correct_count=correct_count+1,due_at=datetime('now','+1 day') WHERE user_id=? AND word_id=?"
        : "UPDATE user_words SET wrong_count=wrong_count+1,due_at=datetime('now') WHERE user_id=? AND word_id=?";
    sqlite3_stmt* update = nullptr;
    sqlite3_prepare_v2(db_,sql,-1,&update,nullptr);
    sqlite3_bind_int(update,1,userId);
    sqlite3_bind_int(update,2,wordId);
    ok = sqlite3_step(update) == SQLITE_DONE;
    sqlite3_finalize(update);
    return ok;
}

int Database::totalLearned(int userId) {
    sqlite3_stmt* s=nullptr;
    sqlite3_prepare_v2(db_,"SELECT COUNT(*) FROM user_words WHERE user_id=?",-1,&s,nullptr);
    sqlite3_bind_int(s,1,userId); int n=0;
    if(sqlite3_step(s)==SQLITE_ROW)n=sqlite3_column_int(s,0);
    sqlite3_finalize(s); return n;
}
int Database::dueCount(int userId) {
    sqlite3_stmt* s=nullptr;
    sqlite3_prepare_v2(db_,"SELECT COUNT(*) FROM user_words WHERE user_id=? AND due_at<=datetime('now')",-1,&s,nullptr);
    sqlite3_bind_int(s,1,userId); int n=0;
    if(sqlite3_step(s)==SQLITE_ROW)n=sqlite3_column_int(s,0);
    sqlite3_finalize(s); return n;
}
int Database::correctAnswers(int userId) {
    sqlite3_stmt* s=nullptr;
    sqlite3_prepare_v2(db_,"SELECT COUNT(*) FROM answer_history WHERE user_id=? AND is_correct=1",-1,&s,nullptr);
    sqlite3_bind_int(s,1,userId); int n=0;
    if(sqlite3_step(s)==SQLITE_ROW)n=sqlite3_column_int(s,0);
    sqlite3_finalize(s); return n;
}
