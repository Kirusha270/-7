#include "security.h"
#include <openssl/sha.h>
#include <iomanip>
#include <sstream>
#include <random>

std::string sha256(const std::string& value) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(value.c_str()), value.size(), hash);
    std::ostringstream out;
    for (unsigned char c : hash) out << std::hex << std::setw(2) << std::setfill('0') << (int)c;
    return out.str();
}

std::string makeToken() {
    static const char chars[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(0, sizeof(chars)-2);
    std::string token;
    for (int i=0;i<48;++i) token += chars[dist(gen)];
    return token;
}
