#pragma once
#include <string>
std::string sha256(const std::string& value);
std::string makeToken();
