#pragma once
#include <string>
#include <vector>
#include <optional>
#include <nlohmann/json.hpp>
#include <mutex>

struct Word {
    int id{};
    std::string english;
    std::string translation;
    std::string example;
    std::string level;
};

class Database {
public:
    explicit Database(const std::string& path);
    bool registerUser(const std::string& username, const std::string& passwordHash);
    std::optional<int> authenticate(const std::string& username, const std::string& passwordHash);
    std::vector<Word> getWords(int userId);
    bool addWord(int userId, const std::string& english, const std::string& translation,
                 const std::string& example, const std::string& level);
    bool deleteWord(int userId, int wordId);
    std::optional<Word> nextWord(int userId);
    bool recordAnswer(int userId, int wordId, bool correct);
    int totalLearned(int userId);
    int dueCount(int userId);
    int correctAnswers(int userId);

private:
    using json = nlohmann::json;
    json data_;
    std::string path_;
    std::mutex mutex_;

    void load();
    void save();
    void seedWords();
    json* findUser(int userId);
    const json* findUser(int userId) const;
};
