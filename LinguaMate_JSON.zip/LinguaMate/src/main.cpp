#include "database.h"
#include "security.h"
#include "httplib.h"
#include <nlohmann/json.hpp>
#include <unordered_map>
#include <mutex>
#include <iostream>
#include <filesystem>

using json = nlohmann::json;

int main() {
    try {
        Database db("data/linguamate.json");
        httplib::Server server;
        std::unordered_map<std::string,int> sessions;
        std::mutex sessionMutex;

        auto bodyJson = [](const httplib::Request& req) {
            try { return json::parse(req.body); }
            catch (...) { return json::object(); }
        };
        auto userId = [&](const httplib::Request& req) -> int {
            if (!req.has_header("Authorization")) return -1;
            std::string header = req.get_header_value("Authorization");
            const std::string prefix = "Bearer ";
            if (header.rfind(prefix,0) != 0) return -1;
            std::lock_guard<std::mutex> lock(sessionMutex);
            auto it = sessions.find(header.substr(prefix.size()));
            return it == sessions.end() ? -1 : it->second;
        };
        auto unauthorized = [](httplib::Response& res) {
            res.status = 401;
            res.set_content(R"({"error":"Требуется авторизация"})","application/json; charset=utf-8");
        };

        server.Get("/api/health", [](const auto&, auto& res) {
            res.set_content(R"({"status":"ok","app":"LinguaMate"})","application/json; charset=utf-8");
        });

        server.Post("/api/register", [&](const auto& req, auto& res) {
            auto data = bodyJson(req);
            std::string name = data.value("username","");
            std::string password = data.value("password","");
            if (name.size()<3 || password.size()<6) {
                res.status=400;
                res.set_content(R"({"error":"Логин — от 3 символов, пароль — от 6"})","application/json; charset=utf-8");
                return;
            }
            if (!db.registerUser(name,sha256(password))) {
                res.status=409;
                res.set_content(R"({"error":"Такой логин уже существует"})","application/json; charset=utf-8");
                return;
            }
            auto id = db.authenticate(name,sha256(password));
            std::string token = makeToken();
            { std::lock_guard<std::mutex> lock(sessionMutex); sessions[token]=*id; }
            res.set_content(json{{"token",token},{"username",name}}.dump(),"application/json; charset=utf-8");
        });

        server.Post("/api/login", [&](const auto& req, auto& res) {
            auto data=bodyJson(req);
            std::string name=data.value("username","");
            std::string password=data.value("password","");
            auto id=db.authenticate(name,sha256(password));
            if(!id){res.status=401;res.set_content(R"({"error":"Неверный логин или пароль"})","application/json; charset=utf-8");return;}
            std::string token=makeToken();
            {std::lock_guard<std::mutex> lock(sessionMutex);sessions[token]=*id;}
            res.set_content(json{{"token",token},{"username",name}}.dump(),"application/json; charset=utf-8");
        });

        server.Get("/api/me", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            res.set_content(json{{"id",id}}.dump(),"application/json; charset=utf-8");
        });

        server.Get("/api/words", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            json arr=json::array();
            for(const auto& w:db.getWords(id))
                arr.push_back({{"id",w.id},{"english",w.english},{"translation",w.translation},{"example",w.example},{"level",w.level}});
            res.set_content(arr.dump(),"application/json; charset=utf-8");
        });

        server.Post("/api/words", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            auto d=bodyJson(req);
            std::string en=d.value("english",""), ru=d.value("translation",""), ex=d.value("example",""), level=d.value("level","A1");
            if(en.empty()||ru.empty()){res.status=400;res.set_content(R"({"error":"Заполните слово и перевод"})","application/json; charset=utf-8");return;}
            if(!db.addWord(id,en,ru,ex,level)){res.status=500;res.set_content(R"({"error":"Не удалось добавить слово"})","application/json; charset=utf-8");return;}
            res.set_content(R"({"success":true})","application/json; charset=utf-8");
        });

        server.Delete(R"(/api/words/(\d+))", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            int wordId=std::stoi(req.matches[1]);
            if(!db.deleteWord(id,wordId)){res.status=404;res.set_content(R"({"error":"Слово не найдено в вашем словаре"})","application/json; charset=utf-8");return;}
            res.set_content(R"({"success":true})","application/json; charset=utf-8");
        });

        server.Get("/api/learn/next", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            auto w=db.nextWord(id);
            if(!w){res.status=404;res.set_content(R"({"error":"Словарь пуст. Добавьте слова, чтобы начать."})","application/json; charset=utf-8");return;}
            res.set_content(json{{"id",w->id},{"english",w->english},{"translation",w->translation},{"example",w->example},{"level",w->level}}.dump(),"application/json; charset=utf-8");
        });

        server.Post("/api/learn/answer", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            auto d=bodyJson(req);
            int wordId=d.value("wordId",0);
            bool correct=d.value("correct",false);
            if(wordId<=0 || !db.recordAnswer(id,wordId,correct)){res.status=400;res.set_content(R"({"error":"Не удалось сохранить ответ"})","application/json; charset=utf-8");return;}
            res.set_content(json{{"success",true},{"message",correct?"Отлично! Ответ засчитан.":"Слово добавлено в повторение."}}.dump(),"application/json; charset=utf-8");
        });

        server.Get("/api/stats", [&](const auto& req, auto& res) {
            int id=userId(req); if(id<0){unauthorized(res);return;}
            int learned=db.totalLearned(id), due=db.dueCount(id), correct=db.correctAnswers(id);
            res.set_content(json{{"words",learned},{"due",due},{"correct",correct}}.dump(),"application/json; charset=utf-8");
        });

        server.Get("/", [](const auto&, auto& res) {
            res.set_file_content("web/index.html","text/html; charset=utf-8");
        });
        server.set_mount_point("/", "./web");

        std::cout << "LinguaMate запущен: http://localhost:8080\n";
        server.listen("0.0.0.0",8080);
    } catch(const std::exception& e) {
        std::cerr << "Ошибка запуска: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
