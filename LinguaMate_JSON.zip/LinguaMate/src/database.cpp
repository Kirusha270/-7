#include "database.h"
#include <fstream>
#include <algorithm>
#include <chrono>
#include <cctype>
#include <stdexcept>\n#include <utility>

using json = nlohmann::json;

static long long nowSeconds() {
    return std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

static std::string lowerText(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

Database::Database(const std::string& path) : path_(path) {
    load();
    seedWords();
}

void Database::load() {
    std::ifstream in(path_, std::ios::binary);
    if (in.good()) {
        try {
            in >> data_;
            if (!data_.is_object()) throw std::runtime_error("bad data");
        } catch (...) {
            throw std::runtime_error("Не удалось прочитать data.json. Файл повреждён или имеет неверный формат.");
        }
    } else {
        data_ = json{{"nextUserId", 1}, {"users", json::array()}};
        save();
    }
    if (!data_.contains("nextUserId")) data_["nextUserId"] = 1;
    if (!data_.contains("users") || !data_["users"].is_array()) data_["users"] = json::array();
}

void Database::save() {
    std::ofstream out(path_, std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("Не удалось сохранить data.json. Проверьте права доступа к папке.");
    out << data_.dump(2);
    if (!out) throw std::runtime_error("Ошибка записи data.json.");
}

json* Database::findUser(int userId) {
    for (auto& u : data_["users"])
        if (u.value("id", 0) == userId) return &u;
    return nullptr;
}

const json* Database::findUser(int userId) const {
    for (const auto& u : data_["users"])
        if (u.value("id", 0) == userId) return &u;
    return nullptr;
}

void Database::seedWords() {
    bool changed = false;
    for (auto& u : data_["users"]) {
        if (!u.contains("words") || !u["words"].is_array()) {
            u["words"] = json::array();
            changed = true;
        }
        if (!u.contains("history") || !u["history"].is_array()) {
            u["history"] = json::array();
            changed = true;
        }
    }
    if (changed) save();
}

bool Database::registerUser(const std::string& username, const std::string& hash) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (const auto& u : data_["users"])
        if (lowerText(u.value("username", "")) == lowerText(username)) return false;

    const struct Seed { const char* en; const char* ru; const char* ex; const char* level; } words[] = {
        {"apple","яблоко","I eat an apple every morning.","A1"},
        {"journey","путешествие","Our journey was exciting.","A2"},
        {"improve","улучшать","I want to improve my English.","A2"},
        {"careful","осторожный","Be careful when you cross the road.","A1"},
        {"opportunity","возможность","This is a great opportunity.","B1"},
        {"although","хотя","Although it was cold, we went out.","B1"},
        {"environment","окружающая среда","We should protect the environment.","B1"},
        {"reliable","надёжный","She is a reliable friend.","B2"},
        {"achieve","достигать","You can achieve your goals.","B1"},
        {"conversation","разговор","We had a long conversation.","A2"},
        {"borrow","брать взаймы","Can I borrow your pen?","A2"},
        {"quiet","тихий","This is a quiet place.","A1"}
    };

    int id = data_.value("nextUserId", 1);
    json user = {
        {"id", id}, {"username", username}, {"passwordHash", hash},
        {"words", json::array()}, {"history", json::array()}
    };
    int wid = 1;
    for (const auto& w : words) {
        user["words"].push_back({
            {"id", wid++}, {"english", w.en}, {"translation", w.ru},
            {"example", w.ex}, {"level", w.level},
            {"correctCount", 0}, {"wrongCount", 0}, {"dueAt", nowSeconds()}
        });
    }
    data_["users"].push_back(std::move(user));
    data_["nextUserId"] = id + 1;
    save();
    return true;
}

std::optional<int> Database::authenticate(const std::string& username, const std::string& hash) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (const auto& u : data_["users"])
        if (u.value("username", "") == username && u.value("passwordHash", "") == hash)
            return u.value("id", 0);
    return std::nullopt;
}

std::vector<Word> Database::getWords(int userId) {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<Word> result;
    const json* u = findUser(userId);
    if (!u) return result;
    for (const auto& w : (*u)["words"])
        result.push_back({w.value("id",0), w.value("english",""), w.value("translation",""),
                          w.value("example",""), w.value("level","A1")});
    return result;
}

bool Database::addWord(int userId, const std::string& en, const std::string& ru,
                       const std::string& ex, const std::string& level) {
    std::lock_guard<std::mutex> lock(mutex_);
    json* u = findUser(userId);
    if (!u) return false;
    for (const auto& w : (*u)["words"])
        if (lowerText(w.value("english","")) == lowerText(en)) return true;
    int id = 1;
    for (const auto& w : (*u)["words"]) id = std::max(id, w.value("id",0) + 1);
    (*u)["words"].push_back({
        {"id",id},{"english",en},{"translation",ru},{"example",ex},{"level",level},
        {"correctCount",0},{"wrongCount",0},{"dueAt",nowSeconds()}
    });
    save();
    return true;
}

bool Database::deleteWord(int userId, int wordId) {
    std::lock_guard<std::mutex> lock(mutex_);
    json* u = findUser(userId);
    if (!u) return false;
    auto& words = (*u)["words"];
    auto it = std::find_if(words.begin(), words.end(),
        [wordId](const json& w) { return w.value("id",0) == wordId; });
    if (it == words.end()) return false;
    words.erase(it);
    save();
    return true;
}

std::optional<Word> Database::nextWord(int userId) {
    std::lock_guard<std::mutex> lock(mutex_);
    const json* u = findUser(userId);
    if (!u || (*u)["words"].empty()) return std::nullopt;
    const json* best = nullptr;
    for (const auto& w : (*u)["words"]) {
        if (!best ||
            w.value("wrongCount",0) > best->value("wrongCount",0) ||
            (w.value("wrongCount",0) == best->value("wrongCount",0) &&
             w.value("dueAt",0LL) < best->value("dueAt",0LL))) best = &w;
    }
    return Word{best->value("id",0),best->value("english",""),best->value("translation",""),
                best->value("example",""),best->value("level","A1")};
}

bool Database::recordAnswer(int userId, int wordId, bool correct) {
    std::lock_guard<std::mutex> lock(mutex_);
    json* u = findUser(userId);
    if (!u) return false;
    for (auto& w : (*u)["words"]) {
        if (w.value("id",0) != wordId) continue;
        if (correct) {
            w["correctCount"] = w.value("correctCount",0) + 1;
            w["dueAt"] = nowSeconds() + 86400;
        } else {
            w["wrongCount"] = w.value("wrongCount",0) + 1;
            w["dueAt"] = nowSeconds();
        }
        (*u)["history"].push_back({{"wordId",wordId},{"correct",correct},{"answeredAt",nowSeconds()}});
        save();
        return true;
    }
    return false;
}

int Database::totalLearned(int userId) {
    std::lock_guard<std::mutex> lock(mutex_);
    const json* u = findUser(userId);
    return u ? static_cast<int>((*u)["words"].size()) : 0;
}

int Database::dueCount(int userId) {
    std::lock_guard<std::mutex> lock(mutex_);
    const json* u = findUser(userId);
    if (!u) return 0;
    int count = 0;
    for (const auto& w : (*u)["words"])
        if (w.value("dueAt",0LL) <= nowSeconds()) ++count;
    return count;
}

int Database::correctAnswers(int userId) {
    std::lock_guard<std::mutex> lock(mutex_);
    const json* u = findUser(userId);
    if (!u) return 0;
    int count = 0;
    for (const auto& h : (*u)["history"])
        if (h.value("correct",false)) ++count;
    return count;
}
