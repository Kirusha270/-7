cmake_minimum_required(VERSION 3.20)
project(LinguaMate VERSION 1.1 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

include(FetchContent)

# Приложению нужен обычный HTTP для локального запуска.
# HTTPS на сервере можно добавить отдельно при публикации.
set(HTTPLIB_REQUIRE_OPENSSL OFF CACHE BOOL "" FORCE)

FetchContent_Declare(httplib
    GIT_REPOSITORY https://github.com/yhirose/cpp-httplib.git
    GIT_TAG v0.18.3
)
FetchContent_Declare(json
    GIT_REPOSITORY https://github.com/nlohmann/json.git
    GIT_TAG v3.11.3
)
FetchContent_MakeAvailable(httplib json)

find_package(OpenSSL REQUIRED)

add_executable(linguamate
    src/main.cpp
    src/database.cpp
    src/security.cpp
)

target_include_directories(linguamate PRIVATE src)
target_link_libraries(linguamate PRIVATE
    httplib::httplib
    nlohmann_json::nlohmann_json
    OpenSSL::Crypto
)

if(WIN32)
    target_link_libraries(linguamate PRIVATE ws2_32)
endif()

file(COPY ${CMAKE_SOURCE_DIR}/web DESTINATION ${CMAKE_BINARY_DIR})
